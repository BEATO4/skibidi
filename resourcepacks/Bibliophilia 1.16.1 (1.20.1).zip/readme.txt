MOD COMPATS CREDITS

- Ad Astra: Giselle Addon by gisellevonbingen
- Additional Additions by dqu1jjj
- Aileron by Egshels/Team Lodestar
- Alex's Caves by AlexThe668
- Alex's Caves: Stuff & Torpedoes by Furti_Two
- Alex's Mobs by AlexThe668
- Alex's Mobs Interaction by CrimsonCrips
- Allurement by Team Abnormals
- Amethyst Imbuement by fzzyhmstrs
- Apotheosis by Shadows_of_Fire
- Archery Expansion by Nekomaster1000
- Ars Elemental by Alexth99
- Ars Nouveau by baileyholl2
- Backpacked by MrCrayfish
- Better Default Biomes by Xratedjunior
- Better End by Quiqueck
- Better Nether by Quiqueck
- Bewitchment by MoriyaShiine
- Biome Makeover by Lemonszz
- Block Swapper by tinytransfem
- Call of Yucatán by Unusual_Squad
- CoFH Core by TeamCoFH
- Combat Enchantments by dsfhdshdjtsb
- Combat Roll by daedelus_dev
- Consecration by TheIllusiveC4
- Create by Simibubi
- Create: Estrogen by Mayaqq
- Create: Garnished by DakotaPrideModding
- Create Stuff 'N Additions by Furti_Two
- Dash by ModdingLegacy
- Deeper and Darker by KyaniteMods
- Domestication Innovation by AlexThe668
- Draconic Evolution by brandon3055
- Dungeons and Taverns by Nova_Wostra
- Enchancement by MoriyaShiine
- Enchantery by Ordana
- Endless Biomes by MadoctheHadoc
- Enigmatic Legacy by Aizistral
- Enlightend by lixir
- Ensorcellation by TeamCoFH
- Expanded Combat by Userofbricks
- Farmer's Delight by Vectorwing
- FlashFyre's Enchantments by f1ashfyre
- Forbidden and Arcanus by cesar_zorak
- Galosphere by orcinus73
- Go Fish by Draylar1
- Guarding by ExDrill
- Hybrid Aquatic by HybridLabs
- Incantationem by Luligabi12/CafeteriaGuild
- Inventorio by Lizard_OfOz
- I Wanna Skate by AlexThe668
- Jaden's Nether Expansion by ThatJadenXgamer
- Jellyfishing by BlueDuckYT
- Just Enough Guns by MigaMi
- Leap by ModdingLegacy
- Let's Forge Bronze And Iron by szczypikrul
- Majrusz's Enchantments/Wonderful Enchantments by Majrusz
- Malum by sammysemicolon
- Marium's Soulslike Weaponry
- Mo' Enchantments by geosava
- My Nether's Delight by soytutta
- Origins by Apace100
- Passable Foliage by Snownee
- Piglin Proliferation by almightytallestred
- Random Crits by InfernalEclipse
- Simple Spears by icandoodle
- Sortilege by Lyof429
- Soul Bound Enchantment by imoonday1008
- Soul fire'd by CrystalSpider
- Spartan Weaponry by ObliviousSpartan
- Spoorn Dual Wield by spoorn
- Step by ModdingLegacy
- Supplementaries by MehVahdJukaar
- Tactical Shield Overhaul by someaddon
- The Bumblezone by telepathicgrunt
- The Twilight Forest by Benimatic
- The Undergarden by Quek04
- Unusual End by Sweetygamer
- Unusual Fish Mod by Coda1552
- Vein Mining by TheIllusiveC4
- Wizards (RPG Series) by daedelus_dev
- Zenith by safrodev

PLEASE SUPPORT THE ORIGINAL MODS AND THEIR AUTHORS!

* OptiFine, Forge CIT, CIT Resewn, or another mod that supports the MCPatcher format must be installed for this pack to work correctly

PERMISSIONS AND CREDITS

Terms of Use
- DO NOT use any textures featured in this pack in a published or otherwise distributed project
- DO NOT redistribute this pack or post on ANY external website!!
 * only legit downloads are on Curseforge, Modrinth, and Planet Minecraft posted by PareidoliaG
- DO NOT change or modify this pack and repost without permission
- You CAN use this texture pack in a modpack
- You CAN use these textures in a PERSONAL USE ONLY pack

Texture Credits
- Credits for all textures go to PareidoliaG
- Textures are based on Minecraft book texture by Jappa
- Some textures use palettes/design ideas from the listed mods and vanilla